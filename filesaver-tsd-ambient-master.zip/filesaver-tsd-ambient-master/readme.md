# filesaver-tsd-ambient

TypeScript typings for [filesaver](https://github.com/eligrey/FileSaver.js/).

Originally from [DefinitelyTyped](https://github.com/DefinitelyTyped/DefinitelyTyped) (licensed under the MIT license).

## Installation

```
npm install --save-dev retyped-filesaver-tsd-ambient
```

See [retyped](https://github.com/retyped/retyped) for more information.